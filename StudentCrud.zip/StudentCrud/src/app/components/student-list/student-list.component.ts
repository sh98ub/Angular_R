import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { StudentService } from '../../services/student.service';
import { Student } from '../../model/student';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css'
})
export class StudentListComponent implements OnInit {

  students: Student[] = [];

  // Add student
  newId = 0;
  newName = '';
  newEmail = '';
  newAge = 0;

  // Edit student
  editingStudent: Student | null = null;

  constructor(
    private studentService: StudentService
  ) {}

  ngOnInit(): void {
    this.loadStudents();
  }

  // GET
  loadStudents(): void {
    this.studentService.getStudents().subscribe(data => {
      this.students = data;
    });
  }

  // POST
  addStudent(): void {

    const student: Student = {
      id: this.newId,
      name: this.newName,
      email: this.newEmail,
      age: this.newAge
    };

    this.studentService.addStudent(student).subscribe(() => {

      this.loadStudents();

      // Clear inputs
      this.newId = 0;
      this.newName = '';
      this.newEmail = '';
      this.newAge = 0;

    });
  }

  // Prepare student for editing
  editStudent(student: Student): void {

    this.editingStudent = {
      ...student
    };
  }

  // PUT
  updateStudent(): void {

    if (this.editingStudent) {

      this.studentService.updateStudent(
        this.editingStudent
      ).subscribe(() => {

        this.loadStudents();

        this.editingStudent = null;

      });
    }
  }

  // Cancel editing
  cancelEdit(): void {
    this.editingStudent = null;
  }

  // DELETE
  deleteStudent(id: number): void {

    this.studentService.deleteStudent(id).subscribe(() => {

      this.loadStudents();

    });
  }
}