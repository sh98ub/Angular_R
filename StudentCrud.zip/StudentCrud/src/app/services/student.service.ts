import { Injectable } from '@angular/core';
import { Student } from '../model/student';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private apiUrl = 'https://localhost:7000/api/students';

  constructor(private http: HttpClient) {}

  // GET all students
  getStudents() {
    return this.http.get<Student[]>(this.apiUrl);
  }

  // GET one student
  getStudent(id: number) {
    return this.http.get<Student>(
      `${this.apiUrl}/${id}`
    );
  }

  // POST
  addStudent(student: Student) {
    return this.http.post<Student>(
      this.apiUrl,
      student
    );
  }

  // PUT
  updateStudent(student: Student) {
    return this.http.put<Student>(
      `${this.apiUrl}/${student.id}`,
      student
    );
  }

  // DELETE
  deleteStudent(id: number) {
    return this.http.delete(
      `${this.apiUrl}/${id}`
    );
  }
}